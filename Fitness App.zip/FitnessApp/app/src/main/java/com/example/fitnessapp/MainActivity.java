package com.example.fitnessapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.WindowInsetsCompat;
import androidx.activity.EdgeToEdge;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView caloriesIntakeTextView;
    private TextView proteinIntakeTextView;
    private TextView fatIntakeTextView;
    private TextView carbsIntakeTextView;
    private TextView caloriesRamaingTextView;
    private  TextView eatText;

    private ActivityResultLauncher<Intent> calorieInputLauncher;
    private ActivityResultLauncher<Intent> foodResultLauncher;
    private ActivityResultLauncher<Intent> programresultLuncher;

    private  ActivityResultLauncher<Intent> allFoodLuncher;
    private int caloriesIntake = 0;
    private int caloriesRemaing = 0;
    private boolean flag=true;
    private int Proteins = 0;
    private int Fats = 0;
    private int Carbs = 0;
    ArrayList<Program> programList = new ArrayList<>();
    ProgramAdapter adapter;
    RecyclerView recyclerView;
    ArrayList<Food_2> ListOfFood2=new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        eatText=findViewById(R.id.Eat_text);
        caloriesIntakeTextView = findViewById(R.id.Calories_intake);
        proteinIntakeTextView = findViewById(R.id.Protein_num);
        fatIntakeTextView = findViewById(R.id.Fat_num);
        carbsIntakeTextView = findViewById(R.id.Carbs_num);
        caloriesRamaingTextView = findViewById(R.id.Calories_remaining);
        recyclerView = findViewById(R.id.program_view);
        adapter = new ProgramAdapter(programList,this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Launcher για θερμίδες στόχου
        calorieInputLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null &&flag) {
                        int calories = result.getData().getIntExtra("calories", 0);
                        caloriesRemaing = calories;
                        caloriesRamaingTextView.setText(String.valueOf(caloriesRemaing));
                        flag=false;
                    }
                    else if(result.getResultCode() == RESULT_OK && result.getData() != null &&!flag)
                    {
                        int calories = result.getData().getIntExtra("calories", 0);
                        caloriesRemaing = calories-caloriesIntake;
                        caloriesRamaingTextView.setText(String.valueOf(caloriesRemaing));
                    }
                }
        );

        // Launcher για επιστροφή macros από SecondActivity
        foodResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        if(caloriesRemaing!=0)
                        {Intent data = result.getData();
                            int calories = data.getIntExtra("calories_total", 0);
                            int protein = data.getIntExtra("protein_total", 0);
                            int fat = data.getIntExtra("fat_total", 0);
                            int carbs = data.getIntExtra("carbs_total", 0);
                            ArrayList<Food_2> foodFlag=(ArrayList<Food_2>)data.getSerializableExtra("list");
                            for(Food_2 food2:foodFlag)
                            {
                                ListOfFood2.add(food2);
                            }
                            caloriesIntake += calories;
                            Proteins += protein;
                            Fats += fat;
                            Carbs += carbs;

                            // Ενημέρωση TextViews
                            caloriesIntakeTextView.setText(String.valueOf(caloriesIntake));
                            proteinIntakeTextView.setText(String.valueOf(Proteins));
                            fatIntakeTextView.setText(String.valueOf(Fats));
                            carbsIntakeTextView.setText(String.valueOf(Carbs));

                            // Αφαιρούμε θερμίδες από υπόλοιπο
                            caloriesRemaing -= calories;
                            caloriesRamaingTextView.setText(String.valueOf(caloriesRemaing));

                            Toast.makeText(this, "Προστέθηκαν macros!", Toast.LENGTH_SHORT).show(); }
                        else{ Toast.makeText(this, "Εισάγεται Θερμίδες", Toast.LENGTH_SHORT).show(); }
                    }
                }
        );

        programresultLuncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();
                        ArrayList<FullExercise> fullExercises = (ArrayList<FullExercise>) data.getSerializableExtra("list");
                        String name = data.getStringExtra("name");

                        if (name != null && !name.isEmpty() && fullExercises != null && !fullExercises.isEmpty()) {
                            Program program = new Program(name, fullExercises);
                            adapter.addProgram(program);  // Πρόσθεσε το πρόγραμμα
                            adapter.notifyDataSetChanged();  // Ανανεώστε τη λίστα
                        } else {
                            Toast.makeText(this, "Program name or exercises missing", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

// Launcher για την εκκίνηση της δραστηριότητας AllFoodDetail
        allFoodLuncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        // Επεξεργασία των αποτελεσμάτων από την AllFoodDetail δραστηριότητα (αν χρειάζεται)
                    }
                }
        );

        eatText.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AllFoodDetail.class);
            intent.putExtra("foodList", ListOfFood2);  // Προσθήκη της λίστας στο Intent
            allFoodLuncher.launch(intent);
        });

        caloriesIntakeTextView.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AllFoodDetail.class);
            intent.putExtra("foodList", ListOfFood2);  // Προσθήκη της λίστας στο Intent
            allFoodLuncher.launch(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }


    // Κλήση για άνοιγμα SecondActivity με launcher
    public void AddFood(View view) {
        Intent intent = new Intent(this, SecondActivity.class);
        foodResultLauncher.launch(intent);
    }

    // Κλήση για άνοιγμα CalorieInputActivity με launcher
    public void openCalorieInput(View view) {
        Intent intent = new Intent(this, Calorie_input.class);
        calorieInputLauncher.launch(intent);
    }

    public  void AddProgram(View view){
        Intent intent = new Intent(this, AddProgram.class);
        programresultLuncher.launch(intent);
    }
}
