package com.example.fitnessapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Calorie_input extends AppCompatActivity {

    EditText calorieInput;
    Button saveCaloriesButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calorie_input);

        // Σύνδεση με το EditText και το Button
        calorieInput = findViewById(R.id.caloriesInput);
        saveCaloriesButton = findViewById(R.id.saveCaloriesButton);

        // Ρύθμιση του OnClickListener για το κουμπί "Αποθήκευση"
        saveCaloriesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitCalories(v);
            }
        });
    }

    // Μέθοδος για την αποστολή των θερμίδων
    public void submitCalories(View view) {
        // Λήψη της εισαγωγής των θερμίδων από το EditText
        int calories = Integer.parseInt(calorieInput.getText().toString());

        // Δημιουργία Intent για επιστροφή των δεδομένων
        Intent resultIntent = new Intent();
        resultIntent.putExtra("calories", calories);

        // Αποστολή αποτελέσματος πίσω στην MainActivity
        setResult(RESULT_OK, resultIntent);
        finish(); // Κλείσιμο της CalorieInputActivity
    }
}
