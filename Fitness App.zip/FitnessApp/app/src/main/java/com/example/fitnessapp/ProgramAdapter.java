package com.example.fitnessapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ProgramAdapter extends RecyclerView.Adapter<ProgramAdapter.ProgramViewHolder> implements Filterable {

    private List<Program> programList;
    private List<Program> programListFull;
    private Context context;

    private ActivityResultLauncher<Intent> programDetailLuncher;
    public ProgramAdapter(List<Program> programList, Context context) {
        this.programList = programList;
        this.programListFull = new ArrayList<>(programList);  // Κρατάμε αντίγραφο για το φίλτρο
        this.context = context;
    }

    @NonNull
    @Override
    public ProgramViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_program, parent, false);
        return new ProgramViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProgramViewHolder holder, int position) {
        Program program = programList.get(position);
        holder.programName.setText(program.getName());
        // Μετρητής για μυϊκές ομάδες
        Map<String, Integer> muscleCount = new HashMap<>();

        for (FullExercise exercise : program.getFullExercises()) {
            String[] muscles = exercise.getMuscle().split(",");
            for (String muscle : muscles) {
                String trimmedMuscle = muscle.trim();
                muscleCount.put(trimmedMuscle, muscleCount.getOrDefault(trimmedMuscle, 0) + 1);
            }
        }

        // Ταξινόμηση κατά συχνότητα
        List<Map.Entry<String, Integer>> sortedMuscles = new ArrayList<>(muscleCount.entrySet());
        sortedMuscles.sort((a, b) -> b.getValue().compareTo(a.getValue()));  // Φθίνουσα σειρά

        // Επιλογή μέχρι 2 κορυφαίων μυϊκών ομάδων
        List<String> topMuscles = new ArrayList<>();
        for (int i = 0; i < Math.min(2, sortedMuscles.size()); i++) {
            topMuscles.add(sortedMuscles.get(i).getKey());
        }

        // Εμφάνιση μυϊκών ομάδων
        holder.programMuscle.setText(String.join(", ", topMuscles));
        holder.itemView.setOnClickListener(v -> {
            Intent intent=new Intent(context,ProgramDetailActivity.class);
            intent.putExtra("program",program);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return programList.size();
    }

    public void addProgram(Program program) {
        programList.add(program);
        programListFull.add(program);  // Διατηρούμε και τη πλήρη λίστα
        notifyItemInserted(programList.size() - 1);
    }

    @Override
    public Filter getFilter() {
        return programFilter;
    }

    private Filter programFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Program> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(programListFull);  // Αν δεν υπάρχει φίλτρο, δείχνουμε όλα τα δεδομένα
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (Program item : programListFull) {  // Ελέγχουμε στη πλήρη λίστα
                    if (item.getName().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            programList.clear();
            programList.addAll((List) results.values);
            notifyDataSetChanged();  // Ανανεώνουμε τη λίστα
        }
    };

    static class ProgramViewHolder extends RecyclerView.ViewHolder {
        TextView programName;
        TextView programMuscle;

        public ProgramViewHolder(@NonNull View itemView) {
            super(itemView);
            programName = itemView.findViewById(R.id.program_name);
            programMuscle=itemView.findViewById(R.id.muscle_text);
        }
    }
}
