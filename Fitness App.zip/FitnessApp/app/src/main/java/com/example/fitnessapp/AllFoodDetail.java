package com.example.fitnessapp;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class AllFoodDetail extends AppCompatActivity {
    private ListView foodListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_food_detail);

        foodListView = findViewById(R.id.food_list_view);

        // Παίρνουμε τη λίστα των φαγητών από το Intent
        ArrayList<Food_2> foodList = (ArrayList<Food_2>) getIntent().getSerializableExtra("foodList");

        if (foodList != null) {
            // Δημιουργούμε έναν ArrayAdapter για να εμφανίσουμε τα δεδομένα στη ListView
            ArrayList<String> foodNames = new ArrayList<>();
            for (Food_2 food : foodList) {
                foodNames.add(food.getName() + " \n" + food.getCalories() + " Θερμίδες");
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, foodNames);
            foodListView.setAdapter(adapter);
        }
    }
}
