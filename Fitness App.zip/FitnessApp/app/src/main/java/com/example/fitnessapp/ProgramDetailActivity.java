package com.example.fitnessapp;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ProgramDetailActivity extends AppCompatActivity {

    private TextView programNameTextView;
    private ListView exerciseListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.program_detail);

        programNameTextView = findViewById(R.id.programName);
        exerciseListView = findViewById(R.id.exerciseList);

        Program program = (Program) getIntent().getSerializableExtra("program");

        if (program != null) {
            programNameTextView.setText(program.getName());

            // Δημιουργία λίστας με πληροφορίες για τις ασκήσεις
            ArrayList<SpannableString> exerciseDescriptions = new ArrayList<>();

            // Εδώ κάνουμε το proper loop για τις ασκήσεις του προγράμματος
            for (FullExercise ex : program.getFullExercises()) {
                String name = ex.getName();
                String muscle = ex.getMuscle();
                int sets = ex.getSets();
                int reps = ex.getReps();

                // Δημιουργία του κειμένου για την άσκηση
                String line = name + "\n" + muscle + "\n" + "sets: " + sets + "   reps: " + reps;

                // Δημιουργία ενός SpannableString
                SpannableString spannableString = new SpannableString(line);

                // Εφαρμογή bold μόνο στο όνομα της άσκησης
                spannableString.setSpan(new StyleSpan(Typeface.BOLD), 0, name.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

                // Προσθήκη του spannableString στη λίστα
                exerciseDescriptions.add(spannableString);
            }

            // Δημιουργία του ArrayAdapter για να διαχειριστείς την λίστα με τις μορφοποιήσεις
            ArrayAdapter<SpannableString> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, exerciseDescriptions);

            // Εφαρμογή του Adapter στο ListView
            exerciseListView.setAdapter(adapter);
        }
    }
}
